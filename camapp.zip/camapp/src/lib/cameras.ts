export type Camera = {
  id: string;
  name: string;
  brand: "Tapo" | "Qubo";
  streamUrl: string;
};

// Update the URLs and names to match the paths in mediamtx.yml.
// These are examples; a camera shows video only when its MediaMTX path works.
export const cameras: Camera[] = [
  { id: "tapo-1", name: "Lobby", brand: "Tapo", streamUrl: "http://localhost:8888/tapo1/index.m3u8" },
  { id: "tapo-2", name: "Tapo Camera 2", brand: "Tapo", streamUrl: "http://localhost:8888/tapo2/index.m3u8" },
  { id: "tapo-3", name: "Tapo Camera 3", brand: "Tapo", streamUrl: "http://localhost:8888/tapo3/index.m3u8" },
  { id: "tapo-4", name: "Tapo Camera 4", brand: "Tapo", streamUrl: "http://localhost:8888/tapo4/index.m3u8" },
];
