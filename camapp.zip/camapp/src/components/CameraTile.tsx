"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Hls from "hls.js";
import type { Camera } from "@/lib/cameras";

type Props = { camera: Camera };

export default function CameraTile({ camera }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [status, setStatus] = useState("Connecting");
  const [retryKey, setRetryKey] = useState(0);
  const retryTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const scheduleRetry = useCallback((message: string) => {
    setStatus(message);
    if (retryTimer.current) return;
    retryTimer.current = setTimeout(() => {
      retryTimer.current = null;
      setRetryKey((value) => value + 1);
    }, 3000);
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const streamUrl = camera.streamUrl;
    let cancelled = false;
    let hls: Hls | null = null;
    let healthTimer: ReturnType<typeof setInterval> | null = null;
    let lastTime = -1;
    let lastProgressAt = Date.now();

    if (typeof streamUrl !== "string" || !streamUrl.trim()) {
      setStatus("Missing stream URL");
      return;
    }

    setStatus("Connecting");

    const markLive = () => {
      lastTime = video.currentTime;
      lastProgressAt = Date.now();
      setStatus("Live");
    };
    const onTimeUpdate = () => {
      if (video.currentTime !== lastTime) {
        lastTime = video.currentTime;
        lastProgressAt = Date.now();
        if (!video.paused) setStatus("Live");
      }
    };
    const onWaiting = () => setStatus("Buffering");
    const onVideoError = () => scheduleRetry("Playback error — retrying");

    video.addEventListener("playing", markLive);
    video.addEventListener("timeupdate", onTimeUpdate);
    video.addEventListener("waiting", onWaiting);
    video.addEventListener("error", onVideoError);

    if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = streamUrl;
      video.load();
      void video.play().catch(() => setStatus("Ready — press play if needed"));
    } else if (Hls.isSupported()) {
      hls = new Hls({
        enableWorker: true,
        lowLatencyMode: false,
        maxBufferLength: 10,
        manifestLoadingMaxRetry: 3,
        levelLoadingMaxRetry: 3,
        fragLoadingMaxRetry: 3,
      });
      hls.attachMedia(video);
      hls.on(Hls.Events.MEDIA_ATTACHED, () => {
        if (!cancelled) hls?.loadSource(streamUrl);
      });
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        if (!cancelled) void video.play().catch(() => setStatus("Ready — press play if needed"));
      });
      hls.on(Hls.Events.ERROR, (_event, data) => {
        if (cancelled || !data.fatal) return;
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
          setStatus("Network issue — recovering");
          hls?.startLoad();
          // If playback still does not recover, the watchdog below restarts this tile.
          lastProgressAt = Date.now();
        } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
          setStatus("Video issue — recovering");
          hls?.recoverMediaError();
        } else {
          scheduleRetry("Stream unavailable — retrying");
        }
      });
    } else {
      setStatus("This browser cannot play HLS");
    }

    healthTimer = setInterval(() => {
      if (cancelled || video.paused || video.ended) return;
      if (video.readyState >= 2 && Date.now() - lastProgressAt > 20000) {
        scheduleRetry("Video frozen — reconnecting");
      }
    }, 5000);

    return () => {
      cancelled = true;
      if (healthTimer) clearInterval(healthTimer);
      if (retryTimer.current) {
        clearTimeout(retryTimer.current);
        retryTimer.current = null;
      }
      video.removeEventListener("playing", markLive);
      video.removeEventListener("timeupdate", onTimeUpdate);
      video.removeEventListener("waiting", onWaiting);
      video.removeEventListener("error", onVideoError);
      hls?.destroy();
      video.pause();
      video.removeAttribute("src");
      video.load();
    };
  }, [camera.streamUrl, retryKey, scheduleRetry]);

  return (
    <article className="camera-card">
      <div className="camera-heading">
        <div>
          <h2>{camera.name}</h2>
          <p>{camera.brand}</p>
        </div>
        <span className={`status ${status === "Live" ? "status-live" : ""}`}>
          <span className="status-dot" />
          {status}
        </span>
      </div>
      <div className="video-wrapper">
        <video ref={videoRef} autoPlay muted playsInline controls />
        {status !== "Live" && (
          <div className="video-message">
            <span className="camera-icon">◉</span>
            <p>{status}</p>
            <small>Attempting to restore this camera</small>
          </div>
        )}
      </div>
    </article>
  );
}
