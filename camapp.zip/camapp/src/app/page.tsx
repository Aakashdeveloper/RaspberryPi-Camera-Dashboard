"use client";

import { useState } from "react";
import CameraTile from "@/components/CameraTile";
import { cameras } from "@/lib/cameras";

export default function Home() {
  const [refreshKey, setRefreshKey] = useState(0);

  return (
    <main className="dashboard">
      <header className="topbar">
        <div className="brand">
          <div className="brand-icon">C</div>
          <div>
            <h1>Camera Dashboard</h1>
            <p>Local CCTV monitoring</p>
          </div>
        </div>
        <div className="camera-count">
          <span className="count-dot" />
          {cameras.length} cameras configured
        </div>
      </header>

      <section className="welcome">
        <div>
          <h2>Live monitoring</h2>
          <p>Each camera tile retries independently if its stream stops.</p>
        </div>
        <button className="refresh-button" onClick={() => setRefreshKey((key) => key + 1)}>
          ↻ Reconnect all feeds
        </button>
      </section>

      <section className="camera-grid">
        {cameras.map((camera) => (
          <CameraTile key={`${camera.id}-${refreshKey}`} camera={camera} />
        ))}
      </section>

      <footer className="footer">
        <span>Local network dashboard</span>
        <span>Streams are served by MediaMTX.</span>
      </footer>
    </main>
  );
}
