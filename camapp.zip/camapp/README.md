# Camera Dashboard

A starter Next.js dashboard for viewing up to six local camera streams in one browser window. This project does not use Docker.

## Requirements

- Node.js (LTS recommended)
- npm
- MediaMTX installed directly on macOS for RTSP-to-HLS streaming
- Cameras that expose a compatible local RTSP stream

## Run the dashboard

```bash
npm install
npm run dev
```

Open http://localhost:3000.

The dashboard initially shows placeholder stream URLs. Live video will not work until MediaMTX is configured with the real RTSP URLs supported by your camera models.

## Stream URL configuration

Edit `src/lib/cameras.ts`. The example URLs assume MediaMTX HLS is available at `http://localhost:8888` and paths named `tapo1`, `tapo2`, `tapo3`, `tapo4`, `qubo1`, and `qubo2`.

Do not put camera passwords in frontend code or commit them to version control. Configure source credentials in a local MediaMTX configuration file and keep it private.

## Build

```bash
npm run build
npm start
```
